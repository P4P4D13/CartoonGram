package pk1;

//implementare follow observer
public class Follower implements FollowObserver {
    private String name;
    private FollowersWindow followersWindow;

    public Follower(String name, FollowersWindow followersWindow) {
        this.name = name;
        this.followersWindow = followersWindow;
    }

    @Override
    public void update(FollowSubject subject) {
        if (subject.isFollowed()) {
            String message = "Started following " + name;
            System.out.println(message);
            followersWindow.addFollowing(name);
        } else {
            String message = "Unfollowed " + name;
            System.out.println(message);
            followersWindow.removeFollowing(name);
        }
    }

    public String getName() {
        return name;
    }
}
