package pk1;

import javax.swing.*;
import java.awt.*;

public class UserNameLabel extends JLabel {
    private static final long serialVersionUID = 1L;

    public UserNameLabel(String userName) {
        super(userName);
        setBounds(60, 15, 200, 45); // Adjust the position and size as needed
        setOpaque(false); // Make the background transparent
        setBackground(Color.LIGHT_GRAY);
        setHorizontalAlignment(SwingConstants.LEFT);
        setFont(new Font("Arial", Font.BOLD, 14)); // Set font style and size
    }
}
