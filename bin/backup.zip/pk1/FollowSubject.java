package pk1;

import java.util.ArrayList;
import java.util.List;

public class FollowSubject {
    private List<FollowObserver> observers;
    private boolean isFollowed;

    public FollowSubject() {
        observers = new ArrayList<>();
        isFollowed = false;
    }

    public void attach(FollowObserver observer) {
        observers.add(observer);
    }

    public void detach(FollowObserver observer) {
        observers.remove(observer);
    }

    public void notifyObservers() {
        for (FollowObserver observer : observers) {
            observer.update(this);
        }
    }

    public boolean isFollowed() {
        return isFollowed;
    }

    public void setFollowed(boolean isFollowed, FollowersWindow followersWindow, String followerName) {
        this.isFollowed = isFollowed;
        notifyObservers(); // Ensure observers are notified first
        if (isFollowed) {
            followersWindow.addFollowing(followerName);
        } else {
            followersWindow.removeFollowing(followerName);
        }
    }

    public List<FollowObserver> getObservers() {
        return observers;
    }
}
