package pk1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Set;

public class FollowersWindow extends JFrame {
    private static final long serialVersionUID = 1L;
    private Set<String> followersSet;
    private JTextArea followingTextArea;
    private GUIinit mainWindow;

    public FollowersWindow(GUIinit mainWindow) {
        this.mainWindow = mainWindow;

        setTitle("Following List");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        followersSet = new HashSet<>();
        followingTextArea = new JTextArea();
        followingTextArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(followingTextArea);
        add(scrollPane, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainWindow.showMainWindow();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(closeButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Initial message when there are no followers
        updateFollowingList();
    }

    public GUIinit getMainWindow() {
        return mainWindow;
    }

    public void addFollowing(String name) {
        if (followersSet.add(name)) {
            updateFollowingList();
        }
        System.out.println("Adding " + name + " to FollowersWindow"); // Debug print
    }

    public void removeFollowing(String name) {
        if (followersSet.remove(name)) {
            updateFollowingList();
        }
        System.out.println("Removing " + name + " from FollowersWindow"); // Debug print
    }

    private void updateFollowingList() {
        followingTextArea.setText(""); // Clear the text area
        if (followersSet.isEmpty()) {
            followingTextArea.append("You aren't following anyone\n");
        } else {
            for (String follower : followersSet) {
                followingTextArea.append(follower + "\n");
            }
        }
    }

    public void addMessage(String message) {
        followingTextArea.append(message + "\n");
    }
}
