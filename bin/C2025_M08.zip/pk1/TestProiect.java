package pk1;

public class TestProiect {

	public static void main(String[] args) {
		new GUIinit();

	}

}
