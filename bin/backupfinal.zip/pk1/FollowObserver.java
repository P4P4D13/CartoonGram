package pk1;

public interface FollowObserver {
    void update(FollowSubject subject);
}
